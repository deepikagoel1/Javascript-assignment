function abracadabra(s,t,k){
	if((s.length)>k) {
		console.log("No")

	}else{
		console.log("Yes")
	}	
}

abracadabra('ashley','ash',2);